<html>
  <head>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        <?php
          $servername = "localhost";
          $username = "root";
          $password = "";
          $dbname = "pizza";
          $conn = new mysqli($servername, $username, $password, $dbname);
          if ($conn->connect_error) {
              die("Connection failed: " . $conn->connect_error);
          }
          // SQL 쿼리를 이용해서 데이터를 가져오기
          $sql = "SELECT * FROM users";
          $result = $conn->query($sql);
          $data = array();
          $data[] = array('pizza', 'topping');
          $count = 0; // 반복 횟수를 저장할 변수
          while ($row = $result->fetch_assoc()) {
                $data[] = array($row['topping1'], (int)$row['num1']);
                $data[] = array($row['topping2'], (int)$row['num2']);
                $data[] = array($row['topping3'], (int)$row['num3']);
                $data[] = array($row['topping4'], (int)$row['num4']);
                $data[] = array($row['topping5'], (int)$row['num5']);
                $count++;
                if ($count == 2)break;
          }

          $json_data = json_encode($data);
        ?>

        // JSON 형식으로 변환된 데이터를 이용해서 그래프를 그리기
        var data = google.visualization.arrayToDataTable(<?php echo $json_data; ?>);

        var options = {
          title: 'pizza'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="piechart" style="width: 900px; height: 500px;"></div>
  </body>
</html>
